/* ============================================================
   Card Crest — pages/account.js
   Auth, dashboard, saved cards, applications, transactions,
   rewards wallet, referrals, profile, notifications.
   ============================================================ */
(function (w, d) {
  'use strict';
  var UI = w.CC.UI, Auth = w.CC.Auth, C = w.CC.Cards, O = w.CC.Offers,
      CB = w.CC.Cashback, RW = w.CC.Rewards, RF = w.CC.Referrals,
      AP = w.CC.Applications, NT = w.CC.Notifications;
  w.CC.Pages = w.CC.Pages || {};

  /* ---------------- account shell ---------------- */
  function shell(active, title, inner) {
    var items = [
      ['/dashboard', 'Overview'],
      ['/dashboard/cards', 'My cards'],
      ['/dashboard/transactions', 'Transactions'],
      ['/dashboard/applications', 'Applications'],
      ['/rewards', 'Rewards wallet'],
      ['/refer', 'Refer and earn'],
      ['/dashboard/notifications', 'Notifications'],
      ['/profile', 'Profile and settings']
    ];
    return '<div class="wrap section--tight"><div class="dash">' +
      '<nav class="side-nav" aria-label="Account">' +
      items.map(function (i) {
        return '<a href="#' + i[0] + '" class="' + (i[0] === active ? 'is-active' : '') + '">' + i[1] + '</a>';
      }).join('') + '</nav><div>' + inner + '</div></div></div>';
  }

  /* ---------------- /login ---------------- */
  w.CC.Pages.login = function (params, query) {
    if (Auth.current()) { w.CC.Router.go('#/dashboard'); return false; }
    return {
      title: 'Sign in | Card Crest',
      desc: 'Sign in to your Card Crest account.',
      html: '<div class="auth-wrap"><div class="auth-card">' +
        '<h1 class="h1">Welcome back</h1><p class="muted" style="margin-bottom:24px">Sign in to see your cashback, rewards and applications.</p>' +
        '<form id="loginForm" novalidate>' +
        '<div class="field" style="margin-bottom:16px"><label for="l-email">Email address</label>' +
        '<input id="l-email" type="email" autocomplete="email" placeholder="you@example.com"><span class="err">Enter the email you signed up with.</span></div>' +
        '<div class="field" style="margin-bottom:14px"><label for="l-pw">Password</label>' +
        '<div class="pw-wrap"><input id="l-pw" type="password" autocomplete="current-password" placeholder="Your password">' +
        '<button type="button" class="pw-toggle" data-pw="l-pw">Show</button></div><span class="err">Enter your password.</span></div>' +
        '<div class="spread" style="margin-bottom:22px">' +
        '<label class="check"><input type="checkbox" id="l-remember" checked> Keep me signed in</label>' +
        '<button type="button" class="btn btn--link small" data-forgot>Forgot password?</button></div>' +
        '<button class="btn btn--primary btn--block" type="submit">Sign in</button>' +
        '</form>' +
        '<div class="note" style="margin-top:22px"><strong>Demo accounts</strong><br>' +
        'User: demo@cardcrest.in / demo1234<br>Admin: admin@cardcrest.in / admin1234</div>' +
        '<p class="auth-alt">New to Card Crest? <a href="#/signup" style="color:var(--crest); font-weight:600">Create an account</a></p>' +
        '</div></div>',
      mount: function (root) {
        root.querySelector('[data-pw]').onclick = function () {
          var i = root.querySelector('#l-pw');
          i.type = i.type === 'password' ? 'text' : 'password';
          this.textContent = i.type === 'password' ? 'Show' : 'Hide';
        };
        root.querySelector('[data-forgot]').onclick = function () {
          UI.modal({
            title: 'Reset your password',
            body: '<p class="muted">Enter your email and we will send a reset link.</p>' +
              '<div class="field" style="margin-top:16px"><label for="f-email">Email address</label><input id="f-email" type="email"></div>' +
              '<p class="small muted" style="margin-top:14px">Demo mode — no email is actually sent.</p>',
            foot: '<button class="btn btn--ghost" data-x>Cancel</button><button class="btn btn--primary" data-send>Send reset link</button>',
            onMount: function (m) {
              m.querySelector('[data-send]').onclick = function () {
                var v = m.querySelector('#f-email').value.trim();
                if (!v) return UI.toast('Enter your email address', 'error');
                UI.closeModal();
                UI.toast('If that email is registered, a reset link is on its way');
              };
            }
          });
        };
        root.querySelector('#loginForm').addEventListener('submit', function (e) {
          e.preventDefault();
          var email = root.querySelector('#l-email'), pw = root.querySelector('#l-pw');
          var bad = false;
          [email, pw].forEach(function (i) {
            var ok = i.value.trim().length > 0;
            i.closest('.field').classList.toggle('is-bad', !ok);
            if (!ok) bad = true;
          });
          if (bad) return;
          var res = Auth.login(email.value, pw.value);
          if (!res.ok) { UI.toast(res.error, 'error'); return; }
          UI.toast('Signed in as ' + res.user.name);
          w.CC.App.paintAuth();
          w.CC.Router.go(query.next ? '#' + query.next : (res.user.role === 'admin' ? '#/admin' : '#/dashboard'));
        });
      }
    };
  };

  /* ---------------- /signup ---------------- */
  w.CC.Pages.signup = function () {
    if (Auth.current()) { w.CC.Router.go('#/dashboard'); return false; }
    return {
      title: 'Create your account | Card Crest',
      desc: 'Create a free Card Crest account to track cashback and rewards.',
      html: '<div class="auth-wrap"><div class="auth-card">' +
        '<h1 class="h1">Create your account</h1><p class="muted" style="margin-bottom:24px">Free, and it takes about a minute.</p>' +
        '<form id="signupForm" novalidate>' +
        '<div class="field" style="margin-bottom:14px"><label for="s-name">Full name</label><input id="s-name" type="text" autocomplete="name"><span class="err">Tell us what to call you.</span></div>' +
        '<div class="field" style="margin-bottom:14px"><label for="s-email">Email address</label><input id="s-email" type="email" autocomplete="email"><span class="err">Enter a valid email address.</span></div>' +
        '<div class="field" style="margin-bottom:14px"><label for="s-mobile">Mobile number</label><input id="s-mobile" type="tel" autocomplete="tel" placeholder="10 digits"><span class="err">Enter a 10-digit mobile number.</span></div>' +
        '<div class="field" style="margin-bottom:14px"><label for="s-pw">Password</label>' +
        '<div class="pw-wrap"><input id="s-pw" type="password" autocomplete="new-password"><button type="button" class="pw-toggle" data-pw="s-pw">Show</button></div>' +
        '<span class="hint">At least 8 characters.</span><span class="err">Use at least 8 characters.</span></div>' +
        '<div class="field" style="margin-bottom:18px"><label for="s-pw2">Confirm password</label><input id="s-pw2" type="password" autocomplete="new-password"><span class="err">Both passwords need to match.</span></div>' +
        '<label class="check" style="margin-bottom:20px"><input type="checkbox" id="s-terms"> I agree to the <a href="#/legal/terms" style="color:var(--crest)">terms</a> and <a href="#/legal/privacy" style="color:var(--crest)">privacy policy</a>.</label>' +
        '<button class="btn btn--primary btn--block" type="submit">Create account</button></form>' +
        '<p class="auth-alt">Already have an account? <a href="#/login" style="color:var(--crest); font-weight:600">Sign in</a></p>' +
        '</div></div>',
      mount: function (root) {
        root.querySelector('[data-pw]').onclick = function () {
          var i = root.querySelector('#s-pw');
          i.type = i.type === 'password' ? 'text' : 'password';
          this.textContent = i.type === 'password' ? 'Show' : 'Hide';
        };
        root.querySelector('#signupForm').addEventListener('submit', function (e) {
          e.preventDefault();
          var f = {
            name: root.querySelector('#s-name'), email: root.querySelector('#s-email'),
            mobile: root.querySelector('#s-mobile'), pw: root.querySelector('#s-pw'), pw2: root.querySelector('#s-pw2')
          };
          var checks = [
            [f.name, f.name.value.trim().length > 1],
            [f.email, /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(f.email.value.trim())],
            [f.mobile, /^\d{10}$/.test(f.mobile.value.replace(/\D/g, ''))],
            [f.pw, f.pw.value.length >= 8],
            [f.pw2, f.pw2.value === f.pw.value && f.pw2.value.length >= 8]
          ];
          var bad = false;
          checks.forEach(function (c) {
            c[0].closest('.field').classList.toggle('is-bad', !c[1]);
            if (!c[1]) bad = true;
          });
          if (!root.querySelector('#s-terms').checked) {
            UI.toast('Accept the terms to continue', 'error'); bad = true;
          }
          if (bad) return;
          var res = Auth.signup({
            name: f.name.value, email: f.email.value,
            mobile: f.mobile.value.replace(/\D/g, ''), password: f.pw.value
          });
          if (!res.ok) return UI.toast(res.error, 'error');
          UI.toast('Welcome to Card Crest');
          w.CC.App.paintAuth();
          w.CC.Router.go('#/eligibility');
        });
      }
    };
  };

  /* ---------------- /dashboard ---------------- */
  w.CC.Pages.dashboard = function () {
    if (!Auth.require()) return false;
    var u = Auth.current();
    var t = CB.totals(u.id);
    var txns = CB.forUser(u.id).slice(0, 5);
    var apps = AP.forUser(u.id).slice(0, 3);
    var saved = C.saved(u.id);
    var hour = new Date().getHours();
    var greet = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';

    var recCards = C.recommend(C.profileFor(u), {}).slice(0, 2);
    var recOffers = O.query({ section: 'top' }).slice(0, 3);

    var inner =
      '<div class="dash__hi"><h1 class="h1">' + greet + ', <em>' + UI.esc(u.name.split(' ')[0]) + '</em></h1>' +
      '<p class="lede">' + (t.pending > 0
        ? UI.money(t.pending) + ' of cashback is on its way. Here is where everything stands.'
        : 'Here is where everything stands.') + '</p></div>' +

      '<div class="grid g-4" style="margin-bottom:26px">' +
        '<div class="stat stat--accent"><span class="stat__k">Available to redeem</span><span class="stat__v" data-count="' + t.available + '">' + UI.money(t.available) + '</span><span class="stat__sub">Minimum ' + UI.money(RW.MIN) + '</span></div>' +
        '<div class="stat"><span class="stat__k">Pending cashback</span><span class="stat__v">' + UI.money(t.pending) + '</span><span class="stat__sub">Awaiting merchant confirmation</span></div>' +
        '<div class="stat"><span class="stat__k">Confirmed to date</span><span class="stat__v">' + UI.money(t.confirmed) + '</span><span class="stat__sub">Across ' + t.count + ' transactions</span></div>' +
        '<div class="stat"><span class="stat__k">Referral earnings</span><span class="stat__v">' + UI.money(t.referral) + '</span><span class="stat__sub">' + RF.stats(u.id).successful + ' successful referrals</span></div>' +
      '</div>' +

      '<h2 class="h3" style="margin-bottom:12px">Quick actions</h2>' +
      '<div class="quick" style="margin-bottom:32px">' +
        [['#/cards', 'Find a card', 'F'], ['#/compare', 'Compare cards', 'C'], ['#/eligibility', 'Check eligibility', 'E'],
         ['#/offers', 'Explore offers', 'O'], ['#/rewards', 'Redeem rewards', 'R'], ['#/refer', 'Refer a friend', 'S']
        ].map(function (q) {
          return '<a href="' + q[0] + '"><span class="qi">' + q[2] + '</span>' + q[1] + '</a>';
        }).join('') + '</div>' +

      '<div class="grid g-2" style="margin-bottom:28px">' +
        '<div class="panel panel--flush"><div class="panel__head"><h2 class="h3">Recent transactions</h2>' +
        '<a class="btn btn--xs btn--link" href="#/dashboard/transactions">See all</a></div><div class="panel__body">' +
        (txns.length ? txns.map(function (x) {
          var st = O.store(x.storeId);
          return '<div class="spread" style="padding:11px 0; border-bottom:1px solid var(--line-soft)">' +
            '<div><strong style="font-size:.92rem">' + UI.esc(st ? st.name : 'Store') + '</strong>' +
            '<div class="small muted">' + UI.date(x.createdAt) + ' &middot; ' + UI.money(x.amount) + '</div></div>' +
            '<div style="text-align:right"><strong>' + UI.money(x.cashback) + '</strong><br>' + UI.statusBadge(x.status) + '</div></div>';
        }).join('') : '<p class="muted small">No transactions yet. Activate an offer and the first one shows up here.</p>') +
        '</div></div>' +

        '<div class="panel panel--flush"><div class="panel__head"><h2 class="h3">Your applications</h2>' +
        '<a class="btn btn--xs btn--link" href="#/dashboard/applications">See all</a></div><div class="panel__body">' +
        (apps.length ? apps.map(function (a) {
          var card = C.byId(a.cardId);
          return '<div class="spread" style="padding:11px 0; border-bottom:1px solid var(--line-soft)">' +
            '<div><strong style="font-size:.92rem">' + UI.esc(card ? card.name : 'Card') + '</strong>' +
            '<div class="small muted">Applied ' + UI.date(a.createdAt) + '</div></div>' +
            UI.statusBadge(a.status) + '</div>';
        }).join('') : '<p class="muted small">No applications yet.</p>') +
        '</div></div>' +
      '</div>' +

      '<div class="spread" style="margin-bottom:16px"><h2 class="h2">Cards worth a look</h2>' +
      '<a class="btn btn--ghost btn--sm" href="#/cards">All cards</a></div>' +
      '<div class="mkt__grid" style="margin-bottom:32px" id="dashCards">' +
        (recCards.length ? recCards.map(function (r) { return w.CC.Render.cardTile(r.card); }).join('')
          : UI.empty('Add your income to get matches', 'We need a couple of details before we can rank cards for you.', 'Check eligibility', '#/eligibility')) +
      '</div>' +

      '<div class="spread" style="margin-bottom:16px"><h2 class="h2">Offers picked for you</h2>' +
      '<a class="btn btn--ghost btn--sm" href="#/offers">All offers</a></div>' +
      '<div class="grid g-3" id="dashOffers">' + recOffers.map(w.CC.Render.offerTile).join('') + '</div>';

    return {
      title: 'Your dashboard | Card Crest',
      desc: 'Your cashback, rewards, applications and card recommendations in one place.',
      html: shell('/dashboard', 'Dashboard', inner),
      mount: function (root) {
        w.CC.Render.bindCompare(root);
        w.CC.Render.bindOfferActions(root);
        var c = root.querySelector('[data-count]');
        if (c) UI.countUp(c, Number(c.dataset.count), function (n) { return UI.money(n); });
      }
    };
  };

  /* ---------------- /dashboard/cards ---------------- */
  w.CC.Pages.myCards = function () {
    if (!Auth.require()) return false;
    var u = Auth.current();
    var saved = C.saved(u.id);

    var inner = '<div class="spread section__head"><div><h1 class="h1">My cards</h1>' +
      '<p class="lede">Cards you have saved, with what each is worth over a year at an average spending pattern.</p></div>' +
      '<a class="btn btn--primary btn--sm" href="#/cards">Add a card</a></div>' +
      (saved.length ? '<div class="stack">' + saved.map(function (s) {
        var card = C.byId(s.cardId);
        if (!card) return '';
        var sc = C.score(card);
        var renew = new Date(s.savedAt); renew.setFullYear(renew.getFullYear() + 1);
        return '<div class="panel"><div class="row row--wrap" style="gap:20px; align-items:flex-start">' +
          '<div style="width:130px; flex-shrink:0">' + UI.plastic(card) + '</div>' +
          '<div style="flex:1; min-width:200px">' +
          '<div class="row" style="gap:10px; margin-bottom:6px">' +
          '<h3 class="h3" style="font-size:1.1rem">' + UI.esc(card.name) + '</h3>' +
          (s.primary ? '<span class="badge">Primary</span>' : '') + '</div>' +
          '<div class="small muted" style="margin-bottom:12px">' + UI.esc(C.bank(card.bank).name) + ' &middot; saved ' + UI.date(s.savedAt) + '</div>' +
          '<div class="grid g-3" style="gap:14px">' +
          '<div><span class="fact__k">Annual fee</span><span class="fact__v">' + (card.annualFee ? UI.money(card.annualFee) : 'None') + '</span></div>' +
          '<div><span class="fact__k">Est. yearly value</span><span class="fact__v" style="color:var(--crest)">' + UI.money(sc.value.net) + '</span></div>' +
          '<div><span class="fact__k">Renews</span><span class="fact__v">' + UI.date(renew.toISOString()) + '</span></div>' +
          '</div></div>' +
          '<div style="text-align:center">' + UI.gauge(sc.total, false) + '</div>' +
          '</div>' +
          '<div class="row row--wrap" style="margin-top:18px; gap:8px">' +
          '<a class="btn btn--ghost btn--sm" href="#/cards/' + card.id + '">Benefits</a>' +
          '<a class="btn btn--ghost btn--sm" href="#/calculator?card=' + card.id + '">Model my spend</a>' +
          (s.primary ? '' : '<button class="btn btn--soft btn--sm" data-primary="' + s.id + '">Make primary</button>') +
          '<button class="btn btn--danger btn--sm" data-remove="' + card.id + '" style="margin-left:auto">Remove</button>' +
          '</div></div>';
      }).join('') + '</div>'
        : UI.empty('No saved cards yet',
          'Save a card and it lands here with its renewal date and what it is worth to you over a year.',
          'Browse credit cards', '#/cards'));

    return {
      title: 'My cards | Card Crest',
      html: shell('/dashboard/cards', 'My cards', inner),
      mount: function (root) {
        root.querySelectorAll('[data-primary]').forEach(function (b) {
          b.onclick = function () {
            C.setPrimary(u.id, b.dataset.primary);
            UI.toast('Primary card updated');
            w.CC.Router.refresh();
          };
        });
        root.querySelectorAll('[data-remove]').forEach(function (b) {
          b.onclick = function () {
            var card = C.byId(b.dataset.remove);
            UI.confirm('Remove ' + card.name + '?', 'It disappears from this list. You can save it again at any time.',
              'Remove card', function () {
                C.unsave(u.id, b.dataset.remove);
                UI.toast('Card removed');
                w.CC.Router.refresh();
              }, true);
          };
        });
      }
    };
  };

  /* ---------------- /dashboard/applications ---------------- */
  w.CC.Pages.applications = function () {
    if (!Auth.require()) return false;
    var u = Auth.current();
    var apps = AP.forUser(u.id);

    var inner = '<div class="section__head"><h1 class="h1">Applications</h1>' +
      '<p class="lede">Every card application you have started, and where the bank has got to.</p></div>' +
      (apps.length ? '<div class="stack">' + apps.map(function (a) {
        var card = C.byId(a.cardId);
        var stage = AP.stageIndex(a.status);
        return '<div class="panel">' +
          '<div class="spread" style="margin-bottom:20px; align-items:flex-start">' +
          '<div class="row" style="gap:14px">' +
          '<div style="width:78px">' + UI.plastic(card, true) + '</div>' +
          '<div><h3 class="h3">' + UI.esc(card ? card.name : 'Card') + '</h3>' +
          '<div class="small muted">Reference ' + a.id + ' &middot; ' + UI.date(a.createdAt) + '</div></div></div>' +
          UI.statusBadge(a.status) + '</div>' +
          '<div class="tl">' + AP.FLOW.map(function (f, i) {
            var cls = a.status === 'rejected' && i === 3 ? 'is-now'
              : i < stage ? 'is-done' : i === stage ? 'is-now' : '';
            var desc = (a.status === 'rejected' && i === 3)
              ? 'The bank did not approve this application.' : f.desc;
            return '<div class="tl__i ' + cls + '"><div class="tl__t">' + f.label + '</div>' +
              '<div class="tl__d">' + UI.esc(desc) + '</div></div>';
          }).join('') + '</div>' +
          (a.notes && a.notes.length ? '<div class="note" style="margin-top:16px"><strong>Note from the bank</strong><br>' +
            UI.esc(a.notes[a.notes.length - 1].text) + '</div>' : '') +
          (a.status === 'documents' ? '<button class="btn btn--primary btn--sm" style="margin-top:16px" data-docs="' + a.id + '">Upload documents</button>' : '') +
          '</div>';
      }).join('') + '</div>'
        : UI.empty('No applications yet',
          'When you apply for a card through Card Crest, you can follow the bank\'s progress here step by step.',
          'Find a card to apply for', '#/cards')) +
      '<p class="small muted" style="margin-top:18px">Demo mode — these applications are simulated. Nothing has been sent to a bank and no credit enquiry has been made.</p>';

    return {
      title: 'Applications | Card Crest',
      html: shell('/dashboard/applications', 'Applications', inner),
      mount: function (root) {
        root.querySelectorAll('[data-docs]').forEach(function (b) {
          b.onclick = function () {
            UI.modal({
              title: 'Upload documents',
              body: '<p class="muted">The bank has asked for an updated address proof.</p>' +
                '<div class="field" style="margin-top:16px"><label for="doc-f">Choose a file</label><input id="doc-f" type="file"></div>' +
                '<p class="small muted" style="margin-top:14px">Demo mode — nothing is uploaded anywhere.</p>',
              foot: '<button class="btn btn--ghost" data-x>Cancel</button><button class="btn btn--primary" data-up>Submit document</button>',
              onMount: function (m) {
                m.querySelector('[data-up]').onclick = function () {
                  AP.setStatus(b.dataset.docs, 'under-review', 'Address proof received and sent for verification.');
                  UI.closeModal();
                  UI.toast('Document submitted');
                  w.CC.Router.refresh();
                };
              }
            });
          };
        });
      }
    };
  };

  /* ---------------- /dashboard/transactions ---------------- */
  w.CC.Pages.transactions = function () {
    if (!Auth.require()) return false;
    var u = Auth.current();
    var f = { status: 'all', q: '' };

    var inner = '<div class="section__head"><h1 class="h1">Transactions</h1>' +
      '<p class="lede">Every tracked purchase and where its cashback has got to.</p></div>' +
      '<div class="mkt__bar">' +
      '<div class="chip-row chip-row--scroll">' +
      [['all', 'All'], ['tracked', 'Tracked'], ['pending', 'Pending'], ['confirmed', 'Confirmed'], ['cancelled', 'Cancelled'], ['rejected', 'Rejected']]
        .map(function (s) {
          return '<button class="chip' + (s[0] === 'all' ? ' is-on' : '') + '" data-status="' + s[0] + '">' + s[1] + '</button>';
        }).join('') + '</div>' +
      '<input type="search" id="txnSearch" placeholder="Search by store" aria-label="Search transactions" style="width:220px"></div>' +
      '<div class="panel panel--flush" style="margin-top:18px"><div class="tbl-wrap"><table class="tbl">' +
      '<thead><tr><th>Store</th><th>Date</th><th class="num">Order value</th><th class="num">Cashback</th><th>Status</th></tr></thead>' +
      '<tbody id="txnBody"></tbody></table></div></div>' +
      '<div class="note" style="margin-top:18px">Cashback moves from tracked to pending once the merchant matches the order, and to confirmed after their return window closes — usually 30 to 90 days.</div>';

    return {
      title: 'Transactions | Card Crest',
      html: shell('/dashboard/transactions', 'Transactions', inner),
      mount: function (root) {
        var body = root.querySelector('#txnBody');
        function draw() {
          var list = CB.forUser(u.id, f);
          if (!list.length) {
            body.innerHTML = '<tr><td colspan="5" style="padding:40px; text-align:center" class="muted">' +
              'Nothing here yet. Activate an offer and the transaction appears within 48 hours.</td></tr>';
            return;
          }
          body.innerHTML = list.map(function (x) {
            var st = O.store(x.storeId);
            return '<tr><td><div class="row" style="gap:10px">' +
              (st ? '<div class="logo-badge" style="width:30px;height:30px;border-radius:8px;font-size:.8rem;background:' + st.color + '">' + UI.esc(st.name[0]) + '</div>' : '') +
              '<strong>' + UI.esc(st ? st.name : 'Store') + '</strong></div></td>' +
              '<td class="muted">' + UI.date(x.createdAt) + '</td>' +
              '<td class="num">' + UI.money(x.amount) + '</td>' +
              '<td class="num"><strong>' + UI.money(x.cashback) + '</strong></td>' +
              '<td>' + UI.statusBadge(x.status) + '</td></tr>';
          }).join('');
        }
        root.querySelectorAll('[data-status]').forEach(function (b) {
          b.onclick = function () {
            f.status = b.dataset.status;
            root.querySelectorAll('[data-status]').forEach(function (x) { x.classList.remove('is-on'); });
            b.classList.add('is-on'); draw();
          };
        });
        root.querySelector('#txnSearch').addEventListener('input', UI.debounce(function (e) {
          f.q = e.target.value; draw();
        }, 220));
        draw();
      }
    };
  };

  /* ---------------- /rewards ---------------- */
  w.CC.Pages.rewards = function () {
    if (!Auth.require()) return false;
    var u = Auth.current();
    var t = CB.totals(u.id);
    var history = RW.redemptions(u.id);

    var inner = '<div class="section__head"><h1 class="h1">Rewards wallet</h1>' +
      '<p class="lede">Confirmed cashback and referral rewards, ready to take out.</p></div>' +
      '<div class="grid g-4" style="margin-bottom:26px">' +
        '<div class="stat stat--accent"><span class="stat__k">Available</span><span class="stat__v" data-count="' + t.available + '">' + UI.money(t.available) + '</span><span class="stat__sub">Ready to redeem</span></div>' +
        '<div class="stat"><span class="stat__k">Pending</span><span class="stat__v">' + UI.money(t.pending) + '</span><span class="stat__sub">Not yet confirmed</span></div>' +
        '<div class="stat"><span class="stat__k">Lifetime earned</span><span class="stat__v">' + UI.money(t.lifetime) + '</span><span class="stat__sub">Cashback and referrals</span></div>' +
        '<div class="stat"><span class="stat__k">Already redeemed</span><span class="stat__v">' + UI.money(t.redeemed) + '</span><span class="stat__sub">' + history.length + ' redemptions</span></div>' +
      '</div>' +
      '<div class="panel" style="margin-bottom:26px"><div class="spread row--wrap" style="gap:14px">' +
      '<div><h2 class="h3">Take your rewards out</h2>' +
      '<p class="muted small" style="margin-top:4px">Minimum ' + UI.money(RW.MIN) + '. UPI and bank transfers land within two working days; gift cards are instant.</p></div>' +
      '<button class="btn btn--primary" data-redeem' + (t.available < RW.MIN ? ' disabled' : '') + '>Redeem ' + UI.money(t.available) + '</button>' +
      '</div>' + (t.available < RW.MIN ? '<div class="note note--warn" style="margin-top:16px">You need ' + UI.money(RW.MIN - t.available) + ' more in confirmed rewards before you can redeem.</div>' : '') + '</div>' +

      '<h2 class="h2" style="margin-bottom:16px">Redemption history</h2>' +
      '<div class="panel panel--flush"><div class="tbl-wrap"><table class="tbl">' +
      '<thead><tr><th>Reference</th><th>Date</th><th>Method</th><th class="num">Amount</th><th>Status</th></tr></thead><tbody>' +
      (history.length ? history.map(function (r) {
        return '<tr><td class="mono small">' + r.ref + '</td><td class="muted">' + UI.date(r.createdAt) + '</td>' +
          '<td>' + UI.esc(r.method) + '</td><td class="num"><strong>' + UI.money(r.amount) + '</strong></td>' +
          '<td>' + UI.statusBadge(r.status) + '</td></tr>';
      }).join('') : '<tr><td colspan="5" style="padding:40px; text-align:center" class="muted">No redemptions yet.</td></tr>') +
      '</tbody></table></div></div>' +
      '<p class="small muted" style="margin-top:16px">Demo mode — redemptions are recorded and marked processed locally. No real transfer is made to any UPI handle or bank account.</p>';

    return {
      title: 'Rewards wallet | Card Crest',
      desc: 'Your confirmed cashback and referral rewards, and how to redeem them.',
      html: shell('/rewards', 'Rewards', inner),
      mount: function (root) {
        var c = root.querySelector('[data-count]');
        if (c) UI.countUp(c, Number(c.dataset.count), function (n) { return UI.money(n); });

        var btn = root.querySelector('[data-redeem]');
        if (btn) btn.onclick = function () {
          UI.modal({
            title: 'Redeem your rewards',
            body: '<div class="field" style="margin-bottom:16px"><label for="r-amt">Amount</label>' +
              '<input id="r-amt" type="number" min="' + RW.MIN + '" max="' + t.available + '" value="' + t.available + '">' +
              '<span class="hint">Between ' + UI.money(RW.MIN) + ' and ' + UI.money(t.available) + '.</span></div>' +
              '<div class="field" style="margin-bottom:16px"><label for="r-method">Send it to</label>' +
              '<select id="r-method">' + RW.methods.map(function (m) { return '<option>' + m + '</option>'; }).join('') + '</select></div>' +
              '<div class="field"><label for="r-dest" id="r-dest-l">UPI ID</label><input id="r-dest" type="text" placeholder="name@bank"></div>' +
              '<div class="note" style="margin-top:16px">Demo mode — this records a redemption and marks it processed. No money moves.</div>',
            foot: '<button class="btn btn--ghost" data-x>Cancel</button><button class="btn btn--primary" data-go>Confirm redemption</button>',
            onMount: function (m) {
              var method = m.querySelector('#r-method'), dest = m.querySelector('#r-dest'), lbl = m.querySelector('#r-dest-l');
              method.onchange = function () {
                var v = method.value;
                lbl.textContent = v === 'UPI' ? 'UPI ID' : v === 'Bank transfer' ? 'Account number' : 'Email for the gift card';
                dest.placeholder = v === 'UPI' ? 'name@bank' : v === 'Bank transfer' ? 'Account number' : 'you@example.com';
                dest.value = '';
              };
              m.querySelector('[data-go]').onclick = function () {
                var res = RW.payout(u.id, Number(m.querySelector('#r-amt').value), method.value, dest.value.trim());
                if (!res.ok) return UI.toast(res.error, 'error');
                UI.closeModal();
                UI.modal({
                  title: 'Redemption requested',
                  body: '<div class="note" style="margin-bottom:16px">Demo redemption processed successfully.</div>' +
                    '<div class="spread" style="padding:12px 0"><span class="muted small">Reference</span><code class="mono">' + res.redemption.ref + '</code></div>' +
                    '<div class="spread" style="padding:12px 0; border-top:1px solid var(--line-soft)"><span class="muted small">Amount</span><strong>' + UI.money(res.redemption.amount) + '</strong></div>' +
                    '<div class="spread" style="padding:12px 0; border-top:1px solid var(--line-soft)"><span class="muted small">Method</span><strong>' + UI.esc(res.redemption.method) + '</strong></div>' +
                    '<p class="small muted" style="margin-top:14px">No real transfer has been made. In production this is where a payout API would be called.</p>',
                  foot: '<button class="btn btn--primary" data-x>Done</button>'
                });
                setTimeout(function () { w.CC.Router.refresh(); }, 400);
              };
            }
          });
        };
      }
    };
  };

  /* ---------------- /refer ---------------- */
  w.CC.Pages.refer = function () {
    if (!Auth.require()) return false;
    var u = Auth.current();
    var code = Auth.referralCode(u);
    var link = RF.link(u);
    var s = RF.stats(u.id);
    var list = RF.forUser(u.id);

    var inner = '<div class="section__head"><h1 class="h1">Refer and <em>earn</em></h1>' +
      '<p class="lede">When someone signs up with your code and gets their first card approved through Card Crest, you both get ' + UI.money(RF.REWARD) + '.</p></div>' +
      '<div class="panel" style="margin-bottom:24px">' +
      '<h2 class="h3" style="margin-bottom:12px">Your referral code</h2>' +
      '<div class="copy-box" style="margin-bottom:14px"><code>' + code + '</code>' +
      '<button class="btn btn--sm btn--soft" data-copy="' + code + '">Copy code</button></div>' +
      '<div class="copy-box" style="margin-bottom:18px"><code style="font-size:.82rem">' + link + '</code>' +
      '<button class="btn btn--sm btn--soft" data-copy="' + link + '">Copy link</button></div>' +
      '<div class="row row--wrap">' +
      '<button class="btn btn--primary btn--sm" data-share>Share</button>' +
      '<a class="btn btn--ghost btn--sm" target="_blank" rel="noopener" href="https://wa.me/?text=' +
        encodeURIComponent('I use Card Crest to find credit cards that actually pay back. Sign up with my code ' + code + ' and we both earn a reward: ' + link) + '">WhatsApp</a>' +
      '</div></div>' +
      '<div class="grid g-4" style="margin-bottom:26px">' +
        '<div class="stat"><span class="stat__k">Total referrals</span><span class="stat__v">' + s.total + '</span></div>' +
        '<div class="stat"><span class="stat__k">Successful</span><span class="stat__v">' + s.successful + '</span></div>' +
        '<div class="stat"><span class="stat__k">Pending</span><span class="stat__v">' + s.pending + '</span></div>' +
        '<div class="stat stat--accent"><span class="stat__k">Earned</span><span class="stat__v">' + UI.money(s.earned) + '</span></div>' +
      '</div>' +
      '<h2 class="h2" style="margin-bottom:16px">Referral history</h2>' +
      '<div class="panel panel--flush"><div class="tbl-wrap"><table class="tbl">' +
      '<thead><tr><th>Friend</th><th>Joined</th><th>Status</th><th class="num">Reward</th></tr></thead><tbody>' +
      (list.length ? list.map(function (r) {
        return '<tr><td><strong>' + UI.esc(r.name) + '</strong></td><td class="muted">' + UI.date(r.createdAt) + '</td>' +
          '<td>' + UI.statusBadge(r.status) + '</td><td class="num">' + (r.reward ? UI.money(r.reward) : '—') + '</td></tr>';
      }).join('') : '<tr><td colspan="4" style="padding:40px; text-align:center" class="muted">No referrals yet. Share your code to get started.</td></tr>') +
      '</tbody></table></div></div>' +
      '<p class="small muted" style="margin-top:16px">Rewards stay pending until the bank confirms the approval, and are reversed if an application is cancelled. Demo mode — referral rewards are simulated.</p>';

    return {
      title: 'Refer and earn | Card Crest',
      desc: 'Share your Card Crest code and earn when a friend gets their first card approved.',
      html: shell('/refer', 'Refer', inner),
      mount: function (root) {
        root.querySelectorAll('[data-copy]').forEach(function (b) {
          b.onclick = function () {
            navigator.clipboard && navigator.clipboard.writeText(b.dataset.copy);
            UI.toast(b.dataset.copy.indexOf('http') === 0 ? 'Referral link copied' : 'Referral code copied');
          };
        });
        root.querySelector('[data-share]').onclick = function () {
          var payload = { title: 'Card Crest', text: 'Find a credit card that actually pays back. Use my code ' + code + '.', url: link };
          if (navigator.share) navigator.share(payload).catch(function () {});
          else {
            navigator.clipboard && navigator.clipboard.writeText(link);
            UI.toast('Referral link copied');
          }
        };
      }
    };
  };

  /* ---------------- /dashboard/notifications ---------------- */
  w.CC.Pages.notifications = function () {
    if (!Auth.require()) return false;
    var u = Auth.current();
    var list = NT.forUser(u.id);

    var inner = '<div class="spread section__head"><div><h1 class="h1">Notifications</h1>' +
      '<p class="lede">Cashback, applications, rewards and offers.</p></div>' +
      (list.length ? '<button class="btn btn--ghost btn--sm" data-all>Mark all as read</button>' : '') + '</div>' +
      '<div class="panel">' + (list.length ? list.map(function (n) {
        return '<div class="notif' + (n.read ? ' is-read' : '') + '" data-n="' + n.id + '">' +
          '<span class="notif__dot"></span>' +
          '<div style="flex:1"><div class="notif__t">' + UI.esc(n.title) + '</div>' +
          '<div class="notif__d">' + UI.esc(n.body) + '</div></div>' +
          '<span class="notif__ts">' + UI.ago(n.createdAt) + '</span></div>';
      }).join('') : '<p class="muted" style="text-align:center; padding:30px">Nothing to catch up on.</p>') + '</div>';

    return {
      title: 'Notifications | Card Crest',
      html: shell('/dashboard/notifications', 'Notifications', inner),
      mount: function (root) {
        root.querySelectorAll('[data-n]').forEach(function (el) {
          el.onclick = function () {
            NT.markRead(el.dataset.n);
            el.classList.add('is-read');
            w.CC.App.paintAuth();
          };
        });
        var all = root.querySelector('[data-all]');
        if (all) all.onclick = function () {
          NT.markAllRead(u.id);
          UI.toast('All notifications marked as read');
          w.CC.App.paintAuth();
          w.CC.Router.refresh();
        };
      }
    };
  };

  /* ---------------- /profile ---------------- */
  w.CC.Pages.profile = function () {
    if (!Auth.require()) return false;
    var u = Auth.current();

    var inner = '<div class="section__head"><h1 class="h1">Profile and settings</h1>' +
      '<p class="lede">Keeping your income and credit details current makes our eligibility estimates far more useful.</p></div>' +

      '<div class="panel" style="margin-bottom:20px"><h2 class="h3" style="margin-bottom:18px">Personal information</h2>' +
      '<div class="form-grid">' +
      '<div class="field"><label for="p-name">Full name</label><input id="p-name" type="text" value="' + UI.esc(u.name) + '"></div>' +
      '<div class="field"><label for="p-city">City</label><input id="p-city" type="text" value="' + UI.esc(u.city || '') + '"></div>' +
      '<div class="field"><label for="p-email">Email address</label><input id="p-email" type="email" value="' + UI.esc(u.email) + '"></div>' +
      '<div class="field"><label for="p-mobile">Mobile number</label><input id="p-mobile" type="tel" value="' + UI.esc(u.mobile || '') + '"></div>' +
      '</div><button class="btn btn--primary btn--sm" style="margin-top:18px" data-save-personal>Save changes</button></div>' +

      '<div class="panel" style="margin-bottom:20px"><h2 class="h3" style="margin-bottom:18px">Financial profile</h2>' +
      '<div class="form-grid">' +
      '<div class="field"><label for="p-emp">Employment</label><select id="p-emp">' +
      ['Salaried', 'Self-employed', 'Business owner', 'Student', 'Retired'].map(function (x) {
        return '<option' + (u.employment === x ? ' selected' : '') + '>' + x + '</option>';
      }).join('') + '</select></div>' +
      '<div class="field"><label for="p-inc">Gross annual income</label><input id="p-inc" type="number" step="10000" value="' + (u.income || 0) + '"></div>' +
      '<div class="field"><label for="p-cr">Credit score</label><input id="p-cr" type="number" min="0" max="900" value="' + (u.credit || 0) + '">' +
      '<span class="hint">Leave at 0 if you have no credit history yet.</span></div>' +
      '</div><button class="btn btn--primary btn--sm" style="margin-top:18px" data-save-fin>Save changes</button></div>' +

      '<div class="panel" style="margin-bottom:20px"><h2 class="h3" style="margin-bottom:8px">Referral</h2>' +
      '<p class="muted small" style="margin-bottom:14px">Your permanent code. It never changes.</p>' +
      '<div class="copy-box"><code>' + Auth.referralCode(u) + '</code>' +
      '<a class="btn btn--sm btn--soft" href="#/refer">Open refer and earn</a></div></div>' +

      '<div class="panel" style="margin-bottom:20px"><h2 class="h3" style="margin-bottom:18px">Security</h2>' +
      '<div class="form-grid">' +
      '<div class="field"><label for="p-old">Current password</label><input id="p-old" type="password"></div>' +
      '<div class="field"><label for="p-new">New password</label><input id="p-new" type="password"><span class="hint">At least 8 characters.</span></div>' +
      '</div><button class="btn btn--primary btn--sm" style="margin-top:18px" data-save-pw>Update password</button></div>' +

      '<div class="panel"><h2 class="h3" style="margin-bottom:8px">Demo data</h2>' +
      '<p class="muted small" style="margin-bottom:14px">Everything you do here is stored in your browser. Resetting restores the original demo dataset and signs you out.</p>' +
      '<button class="btn btn--danger btn--sm" data-reset>Reset demo data</button></div>';

    return {
      title: 'Profile | Card Crest',
      html: shell('/profile', 'Profile', inner),
      mount: function (root) {
        root.querySelector('[data-save-personal]').onclick = function () {
          var name = root.querySelector('#p-name').value.trim();
          var email = root.querySelector('#p-email').value.trim();
          if (!name) return UI.toast('Your name cannot be empty', 'error');
          if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return UI.toast('That email address does not look right', 'error');
          Auth.updateProfile({
            name: name, email: email,
            city: root.querySelector('#p-city').value.trim(),
            mobile: root.querySelector('#p-mobile').value.trim()
          });
          UI.toast('Profile updated');
          w.CC.App.paintAuth();
        };
        root.querySelector('[data-save-fin]').onclick = function () {
          Auth.updateProfile({
            employment: root.querySelector('#p-emp').value,
            income: Number(root.querySelector('#p-inc').value) || 0,
            credit: Number(root.querySelector('#p-cr').value) || 0
          });
          UI.toast('Financial profile updated');
        };
        root.querySelector('[data-save-pw]').onclick = function () {
          var oldPw = root.querySelector('#p-old').value, newPw = root.querySelector('#p-new').value;
          if (newPw.length < 8) return UI.toast('Use at least 8 characters', 'error');
          var res = Auth.changePassword(oldPw, newPw);
          if (!res.ok) return UI.toast(res.error, 'error');
          root.querySelector('#p-old').value = ''; root.querySelector('#p-new').value = '';
          UI.toast('Password updated');
        };
        root.querySelector('[data-reset]').onclick = function () {
          UI.confirm('Reset the demo data?',
            'Your saved cards, transactions, rewards and applications go back to the original demo set. This cannot be undone.',
            'Reset everything', function () {
              w.CC.Store.reset();
              UI.toast('Demo data reset');
              w.CC.App.paintAuth();
              w.CC.Router.go('#/');
            }, true);
        };
      }
    };
  };
})(window, document);
