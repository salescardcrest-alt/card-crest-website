/* ============================================================
   Card Crest — authService.js
   Demo auth. Swap the four functions below for real endpoints
   and every screen that calls them keeps working unchanged.
   ============================================================ */
(function (w) {
  'use strict';
  var S = w.CC.Store;

  var Auth = {
    current: function () {
      var id = S.get('session');
      return id ? S.find('users', id) : null;
    },
    isAdmin: function () {
      var u = Auth.current();
      return !!u && u.role === 'admin';
    },
    login: function (email, password) {
      var u = S.where('users', function (x) {
        return x.email.toLowerCase() === String(email).trim().toLowerCase();
      })[0];
      if (!u) return { ok: false, error: 'No account found with that email address.' };
      if (u.password !== password) return { ok: false, error: 'That password does not match our records.' };
      if (!u.active) return { ok: false, error: 'This account has been disabled. Contact support to reopen it.' };
      S.set('session', u.id);
      return { ok: true, user: u };
    },
    signup: function (data) {
      var exists = S.where('users', function (x) {
        return x.email.toLowerCase() === data.email.trim().toLowerCase();
      }).length;
      if (exists) return { ok: false, error: 'An account already uses that email address.' };
      var u = {
        id: S.uid('u'), name: data.name.trim(), email: data.email.trim().toLowerCase(),
        password: data.password, mobile: data.mobile, role: 'user', city: '',
        employment: '', income: 0, credit: 0,
        joined: new Date().toISOString().slice(0, 10), active: true
      };
      S.insert('users', u);
      S.set('session', u.id);
      w.CC.Notifications.push(u.id, 'system', 'Welcome to Card Crest',
        'Start by checking which cards you are eligible for.');
      return { ok: true, user: u };
    },
    logout: function () { S.set('session', null); },
    updateProfile: function (patch) {
      var u = Auth.current();
      if (!u) return { ok: false, error: 'You need to be signed in.' };
      S.update('users', u.id, patch);
      return { ok: true, user: Auth.current() };
    },
    changePassword: function (oldPw, newPw) {
      var u = Auth.current();
      if (!u) return { ok: false, error: 'You need to be signed in.' };
      if (u.password !== oldPw) return { ok: false, error: 'Your current password is not correct.' };
      S.update('users', u.id, { password: newPw });
      return { ok: true };
    },
    referralCode: function (user) {
      var first = (user.name || 'user').split(' ')[0].toUpperCase().replace(/[^A-Z]/g, '');
      return 'CC-' + first.slice(0, 6) + '-' + user.id.slice(-4).toUpperCase();
    },
    /* Gate a route. Returns true if allowed, otherwise redirects. */
    require: function (adminOnly) {
      var u = Auth.current();
      if (!u) {
        w.CC.UI.toast('Sign in to continue', 'error');
        location.hash = '#/login?next=' + encodeURIComponent(location.hash.slice(1));
        return false;
      }
      if (adminOnly && u.role !== 'admin') {
        w.CC.UI.toast('That area is for Card Crest staff', 'error');
        location.hash = '#/dashboard';
        return false;
      }
      return true;
    }
  };

  w.CC.Auth = Auth;
})(window);
